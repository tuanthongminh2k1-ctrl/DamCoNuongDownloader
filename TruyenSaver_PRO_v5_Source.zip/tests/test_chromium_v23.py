"""Regression checks for bundled Chromium selection (no Cốc Cốc requirement)."""
import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).parents[1] / 'app.py'
spec = importlib.util.spec_from_file_location('truyensaver_chromium_v23', MODULE_PATH)
app = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = app
spec.loader.exec_module(app)


class ChromiumPackagingTest(unittest.TestCase):
    def test_app_uses_chromium(self):
        self.assertIn('Chromium', app.APP_NAME)
        self.assertFalse(hasattr(app, 'find_coccoc'))
        self.assertTrue(hasattr(app, 'ChromiumEngine'))

    def test_bundled_path_is_selected_when_frozen(self):
        with tempfile.TemporaryDirectory() as dirname:
            root = Path(dirname)
            (root / 'playwright-browsers').mkdir()
            old_attr = getattr(sys, '_MEIPASS', None)
            had_attr = hasattr(sys, '_MEIPASS')
            old_value = os.environ.get('PLAYWRIGHT_BROWSERS_PATH')
            try:
                sys._MEIPASS = str(root)
                app.configure_chromium_path()
                self.assertEqual(os.environ['PLAYWRIGHT_BROWSERS_PATH'], str(root / 'playwright-browsers'))
            finally:
                if had_attr:
                    sys._MEIPASS = old_attr
                else:
                    del sys._MEIPASS
                if old_value is None:
                    os.environ.pop('PLAYWRIGHT_BROWSERS_PATH', None)
                else:
                    os.environ['PLAYWRIGHT_BROWSERS_PATH'] = old_value

    def test_incomplete_extraction_is_rejected(self):
        with tempfile.TemporaryDirectory() as dirname:
            had_attr = hasattr(sys, '_MEIPASS')
            old_attr = getattr(sys, '_MEIPASS', None)
            try:
                sys._MEIPASS = dirname
                with self.assertRaisesRegex(RuntimeError, 'giải nén'):
                    app.configure_chromium_path()
            finally:
                if had_attr:
                    sys._MEIPASS = old_attr
                else:
                    del sys._MEIPASS

    def test_workflow_bundles_chromium_and_onedir(self):
        workflow = (MODULE_PATH.parent / '.github/workflows/build-windows.yml').read_text(encoding='utf8')
        self.assertIn('playwright install chromium', workflow)
        self.assertIn('--onedir', workflow)
        self.assertIn('--add-data', workflow)
        self.assertIn('playwright-browsers', workflow)


if __name__ == '__main__':
    unittest.main()
