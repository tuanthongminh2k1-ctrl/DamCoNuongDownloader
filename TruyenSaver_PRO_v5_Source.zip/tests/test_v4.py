"""TruyenSaver PRO v4: conditions that caused reported failures."""
import io
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import Mock
from PIL import Image
from pypdf import PdfReader

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from test_pdf import fake_mhtml,make_png


class TestV4(unittest.TestCase):
    def test_theme_assets_and_palette(self):
        self.assertIn('Hsin • Moon Fox',app.THEMES)
        self.assertTrue(app.asset_path('moon_fox_banner.png').exists())
        self.assertEqual(app.VERSION,'5.0.0')

    def test_sayhentai_html_series_uses_correct_chapter_urls(self):
        site='https://sayhentai.cx/truyen-me-hay-con-gai.html'
        links=[{'text':'Chapter 1','href':'/truyen-me-hay-con-gai/chuong-1'},
               {'text':'Chapter 9','href':'/truyen-me-hay-con-gai/chuong-9'},
               {'text':'Chapter 40','href':'/truyen-khac/chuong-40'}]
        self.assertEqual([c['number'] for c in app.extract_chapters(links,site)],[1.0,9.0])

    def test_source_validation_rejects_external_host(self):
        for url in ['http://damconuong.cool/truyen/a',
                    'https://sayhentai.cx.evil.invalid/truyen/a',
                    'file:///C:/path.html']:
            with self.assertRaises(ValueError):app.validate_source(url)

    def test_network_backoff_is_per_host(self):
        health=app.HostHealth()
        a='https://sayhentai.cx/truyen-test/chuong-1'
        b='https://damconuong.cool/truyen/test/chapter-2'
        self.assertGreater(health.failed(a),0)
        self.assertGreater(health.failed(a),0)
        self.assertTrue(health.reduced_concurrency(a))
        self.assertFalse(health.reduced_concurrency(b))
        health.succeeded(a)
        self.assertFalse(health.reduced_concurrency(a))

    def test_stop_interrupts_cooldown(self):
        health=app.HostHealth()
        url='https://sayhentai.cx/truyen-x/chuong-4'
        health.failed(url)
        stop=threading.Event()
        stop.set()
        start=time.monotonic()
        with self.assertRaises(InterruptedError):health.wait(url,stop)
        self.assertLess(time.monotonic()-start,0.3)

    def test_navigation_uses_commit_instead_of_domcontentloaded(self):
        fake=Mock()
        fake.goto.return_value=None
        actor=Mock()
        actor.host_health=app.HostHealth()
        actor.cancel=threading.Event()
        actor.log=lambda _:None
        app.App._navigate_to_chapter(actor,fake,'https://damconuong.cool/truyen/demo/chapter-1')
        self.assertEqual(fake.goto.call_args.kwargs['wait_until'],'commit')
        self.assertLessEqual(fake.goto.call_args.kwargs['timeout'],25000)

    def test_pdf_is_readable_and_has_no_unbounded_page(self):
        urls=[f'https://cdn.example/p{i}.png' for i in range(8)]
        blob=fake_mhtml({u:make_png(180,440,(100+i,120,160)) for i,u in enumerate(urls)})
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)/'Chap_001.pdf'
            app.pdf_from_mhtml(blob,urls,dest)
            pdf=PdfReader(str(dest))
            self.assertGreater(len(pdf.pages),1)
            self.assertTrue(all(float(pg.mediabox.width)==720 for pg in pdf.pages))
            self.assertTrue(all(float(pg.mediabox.height)<=2500 for pg in pdf.pages))
            heights=[Image.open(io.BytesIO(im.data)).height for pg in pdf.pages for im in pg.images]
            self.assertEqual(sum(heights),8*440)

    def test_repeated_story_image_is_kept_twice(self):
        from test_pdf import fake_mhtml
        u='https://cdn.example/shared-panel.png'
        blob=fake_mhtml({u:make_png(220,250,(120,120,150))})
        blob=blob.replace(b'<div class="reading-detail">Reader</div>',
                          b'<div class="reading-detail">'+b'x'*1800+b'</div>')
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'repeat.pdf'
            app.pdf_from_mhtml(blob,[u,u],path)
            pages=PdfReader(str(path)).pages
            import re
            uses=sum(len(re.findall(rb'/[^\s/]+\s+Do\b',
                 p.get_contents().get_data())) for p in pages)
            self.assertEqual(uses,2)

    def test_pdf_incomplete_mhtml_is_not_reported_success(self):
        urls=['https://cdn.example/ok.png','https://cdn.example/missing.png']
        blob=fake_mhtml({urls[0]:make_png(200,200,(200,100,100))})
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)/'broken.pdf'
            with self.assertRaises(ValueError):app.pdf_from_mhtml(blob,urls,dest)
            self.assertFalse(dest.exists())

    def test_self_test_workflow_includes_assets_and_bundle(self):
        config=(Path(__file__).parents[1]/'.github/workflows/build-windows.yml').read_text()
        self.assertIn('playwright install chromium',config)
        self.assertTrue(bool(app.MOON_FOX_BANNER_PNG_BASE64))
        self.assertIn('TruyenSaver_PRO_v5.exe',config)


if __name__=='__main__':unittest.main()
