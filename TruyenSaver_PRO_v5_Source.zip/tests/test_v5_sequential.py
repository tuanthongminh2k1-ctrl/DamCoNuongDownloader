"""Acceptance tests for verified *per-image* persistence and sequential exports."""
import io
import json
import tempfile
import threading
import unittest
from unittest import mock
from pathlib import Path

from PIL import Image
from pypdf import PdfReader
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
from chapter_v5 import (ChapterIncomplete, SequentialChapter, check_image,
                        check_saved_image, get_data_image, write_series_index)


def png(color='blue', width=180, height=350):
    out=io.BytesIO()
    Image.new('RGB',(width,height),color).save(out,format='PNG')
    return out.getvalue()


class TestV5Sequential(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder=Path(self.tmp.name)/'Chap_001'
        self.urls=['https://cdn.example.net/image-1.png',
                   'https://cdn.example.net/image-2.png',
                   'https://cdn.example.net/image-3.png']
        self.payload={u:png(('red','green','blue')[i]) for i,u in enumerate(self.urls)}
        self.stop=threading.Event()
        self.logs=[]

    def store(self, **kwargs):
        ret=SequentialChapter('https://damconuong.cool/comic/demo/chap-1',
                              self.folder,stop=self.stop,log=self.logs.append, **kwargs)
        ret._pause=lambda wait: None
        return ret

    def status(self):
        return json.loads((self.folder/'progress.json').read_text(encoding='utf-8'))

    def test_complete_pdf_and_html_from_local_images_in_correct_order(self):
        calls=[]
        def fetch(url):
            calls.append(url)
            return self.payload[url]
        count,pages=self.store().run(self.urls,fetch,make_pdf=app.pdf_from_local_images,
                                     chapter_title='Truyện đặc biệt - Chương 1')
        self.assertEqual((count,len(calls)),(3,3))
        self.assertGreaterEqual(pages,1)
        self.assertEqual(self.status()['status'],'complete')
        self.assertEqual(len(PdfReader(str(self.folder/'Chap_001.pdf')).pages),pages)
        preview=(self.folder/'DOC_OFFLINE.html').read_text(encoding='utf-8')
        self.assertEqual(preview.count('<img '),3)
        self.assertNotIn('https://cdn.example.net',preview)
        self.assertLess(preview.index('0001.png'),preview.index('0002.png'))
        self.assertLess(preview.index('0002.png'),preview.index('0003.png'))
        write_series_index(self.folder.parent,'Truyện đặc biệt', [('001','Chap_001/DOC_OFFLINE.html')])
        self.assertIn('Chap_001/DOC_OFFLINE.html', (self.folder.parent/'MUC_LUC.html').read_text())

    def test_partial_chapter_stops_without_offline_exports_then_resume(self):
        tried=[]
        def fail_second(url):
            tried.append(url)
            if url == self.urls[1]:
                raise RuntimeError('gián đoạn mạng')
            return self.payload[url]
        with self.assertRaises(ChapterIncomplete):
            self.store().run(self.urls,fail_second,make_pdf=app.pdf_from_local_images)
        self.assertEqual(self.status()['status'],'incomplete')
        self.assertEqual(len(self.status()['items']),1)
        self.assertEqual(tried.count(self.urls[1]),6)  # initial + five retries
        self.assertFalse((self.folder/'DOC_OFFLINE.html').exists())
        self.assertFalse((self.folder/'Chap_001.pdf').exists())
        resumed=[]
        def fetch(url):
            resumed.append(url)
            return self.payload[url]
        self.store().run(self.urls,fetch,make_pdf=app.pdf_from_local_images)
        self.assertEqual(resumed,[self.urls[1],self.urls[2]])
        self.assertEqual(self.status()['status'],'complete')

    def test_broken_jpeg_and_html_response_rejected(self):
        self.assertRaises(Exception,check_image,b'<html>403 Forbidden</html>')
        raw=png()
        self.assertRaises(Exception,check_image,raw[:-16])
        with self.assertRaises(ChapterIncomplete):
            self.store().run([self.urls[0]],lambda url:b'<html>error</html>')
        self.assertFalse((self.folder/'DOC_OFFLINE.html').exists())

    def test_modified_image_never_accepted_as_cached(self):
        self.store().run(self.urls, lambda u:self.payload[u])
        first=self.folder/'images/0001.png'
        first.write_bytes(png('black'))
        self.assertFalse(check_saved_image(first,self.status()['items'][0]))
        downloaded=[]
        self.store().run(self.urls,lambda u:(downloaded.append(u),self.payload[u])[1])
        self.assertEqual(downloaded,[self.urls[0]])

    def test_stop_is_safe_and_saves_previous_verified_image(self):
        def fetch(url):
            if url==self.urls[0]:self.stop.set()
            return self.payload[url]
        with self.assertRaises(InterruptedError):
            self.store().run(self.urls,fetch)
        self.assertEqual(self.status()['status'],'incomplete')
        self.assertEqual(len(self.status()['items']),1)
        self.assertFalse((self.folder/'DOC_OFFLINE.html').exists())

    def test_reject_empty_discovery_and_invalid_source(self):
        with self.assertRaises(ChapterIncomplete):
            self.store().run([],lambda _:png())
        self.assertFalse((self.folder/'DOC_OFFLINE.html').exists())

    def test_images_are_not_mhtml_or_remote_references(self):
        count, pages=self.store().run(self.urls, lambda u:self.payload[u])
        self.assertEqual((count,pages),(3,0))
        self.assertEqual(len(list((self.folder/'images').iterdir())),3)
        self.assertFalse(list(self.folder.rglob('*.mhtml')))

    def test_v5_modes_default_single_worker(self):
        modes={'Ảnh + HTML + PDF':'images_both','Ảnh + HTML offline':'images_html',
               'Ảnh + PDF':'images_pdf'}
        from types import SimpleNamespace
        class Val:
            def __init__(self,x):self.x=x
            def get(self):return self.x
        fake=SimpleNamespace(links=SimpleNamespace(get=lambda *args:self.urls[0].replace('cdn.example.net','damconuong.cool')),
            start_var=Val('1'),end_var=Val('100'),folder_var=Val(self.tmp.name),
            format_var=Val(''),workers_var=Val('3'),ad_free_var=Val(True),_save_settings=lambda:None)
        for label,mode in modes.items():
            fake.format_var.x=label
            *_,actual,workers,_=app.App._fields(fake)
            self.assertEqual(actual,mode)
            self.assertEqual(workers,1)

if __name__=='__main__':unittest.main()

class TestQueueStopsOnFirstIncomplete(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder=Path(self.tmp.name)
        self.base='https://damconuong.cool/truyen/demo'
        self.chapters=[{'number':1.,'url':self.base+'/chapter-1'},
                       {'number':2.,'url':self.base+'/chapter-2'}]
        self.browse=[]
        self.events=[]
        self.messages=[]
        self.mockpage=mock.Mock()
        self.mockpage.context=mock.Mock()
        self.mockpage.close=mock.Mock()
        driver=mock.Mock()
        driver.chromium.connect_over_cdp.return_value.contexts=[mock.Mock()]
        driver.chromium.connect_over_cdp.return_value.contexts[0].new_page.return_value=self.mockpage
        self.context=mock.MagicMock()
        self.context.__enter__.return_value=driver
        self.actor=type('Fake',(),{})()
        self.actor.scanned={}
        self.actor.selection_snapshot=None
        self.actor.cancel=threading.Event()
        self.actor._connect=lambda:(1324,self.context)
        self.actor._discover=lambda *args:('Demo',self.chapters)
        self.actor._navigate_to_chapter=lambda page,url:(self.browse.append(url),None)[1]
        self.actor.log=self.messages.append
        self.actor._emit=lambda *args:self.events.append(args)

    def test_first_incomplete_prevents_second_chapter(self):
        from unittest.mock import patch
        with patch.object(app, 'discover_reader_urls_v5',return_value=['https://img.example/01.png']),\
             patch.object(app, 'fetch_chapter_image_v5',side_effect=RuntimeError('timeout')),\
             patch('chapter_v5.SequentialChapter._pause',lambda self,x:None):
            text=app.App._download(self.actor,[self.base],1,2,self.folder,'images_both',1,True)
        self.assertEqual(self.browse,[self.chapters[0]['url']])
        self.assertIn('dừng',text.lower())
        report=list(self.folder.rglob('BAO_CAO.txt'))
        self.assertEqual(len(report),1)
        self.assertNotIn('Chap_002',str(report[0].parent))

    def test_both_chapters_finish_sequentially(self):
        from unittest.mock import patch
        with patch.object(app, 'discover_reader_urls_v5',return_value=['https://img.example/01.png']),\
             patch.object(app, 'fetch_chapter_image_v5',return_value=png()),\
             patch('chapter_v5.SequentialChapter._pause',lambda self,x:None):
            text=app.App._download(self.actor,[self.base],1,2,self.folder,'images_html',1,True)
        self.assertEqual(self.browse,[c['url'] for c in self.chapters])
        self.assertIn('2/2',text)
        self.assertEqual(len(list(self.folder.rglob('DOC_OFFLINE.html'))),2)
