"""Chromium/CDP smoke test with embedded lazy PNG images; no network needed.
Test browser DOM loading and MHTML verification without relying on any comic site.
"""
from __future__ import annotations
import base64
import struct
import sys
import tempfile
import threading
import zlib
from pathlib import Path
from playwright.sync_api import sync_playwright

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import wait_for_reader
from app import capture_verified_blob, pdf_from_mhtml, save_atomic_bytes, CocCoc


def png(w=220,h=310,shade=130):
    def chunk(tag,data):
        return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
    raw=b''.join(b'\x00'+bytes([shade,140,180])*w for _ in range(h))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')

if __name__=='__main__':
    import os
    import app
    with tempfile.TemporaryDirectory() as directory:
        app.PROFILE_DIR=Path(directory)/'profile'
        browser=CocCoc(os.environ.get('SMOKE_CHROME','/usr/bin/chromium'))
        try:
            port=browser.ensure(visible=False)
            with sync_playwright() as pw:
                remote=pw.chromium.connect_over_cdp(f'http://127.0.0.1:{port}')
                page=remote.contexts[0].new_page()
                try:
                    images=[]
                    for i in range(12):
                        encoded=base64.b64encode(png(shade=70+i)).decode('ascii')
                        src='data:image/png;base64,'+encoded
                        images.append('<img loading="lazy" width="800" height="1100" style="display:block;width:800px;height:1100px;margin:12px 0" data-src="'+src+'"/>')
                    markup='<html><body><aside><img width="200" height="200" src="data:image/png;base64,'+base64.b64encode(png(shade=14)).decode('ascii')+'"></aside><div class="reading-detail">'+''.join(images)+'</div></body></html>'
                    page.set_content(markup, wait_until='domcontentloaded')
                    state=wait_for_reader(page,print,threading.Event(),max_seconds=40)
                    assert state['total']==12, state
                    file=Path(directory)/'Chap_001.mhtml'
                    blob, verification=capture_verified_blob(page,state,print)
                    save_atomic_bytes(blob, file)
                    assert verification.matched==12 and file.stat().st_size>1500
                    pages=pdf_from_mhtml(blob,state['urls'],Path(directory)/'Chap_001.pdf')
                    assert pages>=1
                    print(f'SMOKE PASS: 12/12 reader image URLs MHTML + {pages} PDF pages')
                finally:
                    page.close()
        finally:
            browser.close()
