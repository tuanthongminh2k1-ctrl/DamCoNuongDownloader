"""New v3 acceptance checks: three hosts, exclusive export, PDF without page seams."""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from pypdf import PdfReader

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
from test_pdf import fake_mhtml, make_png


class Var:
    def __init__(self, value): self.value=value
    def get(self): return self.value

class Text:
    def get(self,*args): return 'https://damconuong.cool/truyen/ban-hoc\nhttps://sayhentai.cx/abc.html\nhttps://hentaicube.xyz/truyen/demo'

class TestV3(unittest.TestCase):
    def test_three_domains(self):
        for base in ['damconuong.cool','sayhentai.cx','hentaicube.xyz']:
            self.assertTrue(app.validate_source('https://'+base+'/truyen/test'))
        with self.assertRaises(ValueError):
            app.validate_source('https://hentaicube.xyz.evil.invalid/anything')

    def test_hentaicube_chapter_parser(self):
        url='https://hentaicube.xyz/truyen/my-series'
        data=[{'href':'/truyen/my-series/chapter-1','text':'Chapter 1'},
              {'href':'/truyen/my-series/chapter-1-5','text':'Chapter 1.5'},
              {'href':'/truyen/other-series/chapter-2','text':'Chapter 2'},
              {'href':'/truyen/my-series/chapter-3','text':'Chap 3'}]
        numbers=[x['number'] for x in app.extract_chapters(data,url)]
        self.assertEqual(numbers,[1.0,1.5,3.0])

    def test_exclusive_ui_modes(self):
        fake=SimpleNamespace(links=Text(),start_var=Var('1'),end_var=Var('100'),
                  folder_var=Var(tempfile.gettempdir()),format_var=Var(''),
                  workers_var=Var('2'),ad_free_var=Var(True),_save_settings=lambda:None)
        for label,expected in [('MHTML (đọc offline)','mhtml'),
                               ('PDF riêng (mỗi chap)','pdf'),
                               ('PDF gộp (1 tệp)','merged')]:
            fake.format_var.value=label
            urls,start,end,folder,mode,workers,ads=app.App._fields(fake)
            self.assertEqual(mode,expected)
            self.assertEqual(len(urls),3)
            self.assertEqual(workers,1) # v5 strict sequential
            self.assertTrue(ads)

    def test_pdf_reasonably_sized_pages_for_long_chapter(self):
        with tempfile.TemporaryDirectory() as folder:
            urls=[f'https://cdn.example/{i:03}.png' for i in range(35)]
            images={u:make_png(100,300,'skyblue') for u in urls}
            path=Path(folder)/'Chap_001.pdf'
            page_count=app.pdf_from_mhtml(fake_mhtml(images),urls,path)
            pdf=PdfReader(str(path))
            self.assertEqual(len(pdf.pages),page_count)
            self.assertGreater(page_count,1)
            self.assertTrue(all(float(pg.mediabox.width)>=300 and
                                float(pg.mediabox.height)<=2700 for pg in pdf.pages))
            drawn=sum(len(__import__('re').findall(rb'/[^\s/]+\s+Do\b', pg.get_contents().get_data()))
                      for pg in pdf.pages)
            self.assertEqual(drawn,35)

    def test_extremely_tall_sources_must_be_sliced_first(self):
        with self.assertRaises(ValueError):
            app.plan_continuous_pdf([(10,1000)]*100)
        raw=make_png(40,2000,'navy')
        chunks=app._source_slices(raw)
        self.assertGreater(len(chunks),1)
        from PIL import Image
        from io import BytesIO
        self.assertEqual(sum(Image.open(BytesIO(x)).height for x in chunks),2000)

    def test_merged_only_one_visible_pdf_and_resume(self):
        with tempfile.TemporaryDirectory() as root:
            folder=Path(root); chapters=[
                {'number':1.,'url':'https://damconuong.cool/truyen/demo/chapter-1'},
                {'number':2.,'url':'https://damconuong.cool/truyen/demo/chapter-2'}]
            cache=app.merged_cache_folder(folder,chapters)
            cache.mkdir(parents=True)
            urls=['https://img.example/1.png','https://img.example/2.png']
            blob=fake_mhtml({urls[0]:make_png(140,210,'red'),urls[1]:make_png(140,160,'blue')})
            for chapter in chapters:
                number=app.chapter_label(chapter['number'])
                path=cache/f'Chap_{number}.pdf'
                pages=app.pdf_from_mhtml(blob,urls,path)
                app.write_pdf_manifest(cache,number,chapter['url'],path,len(urls),pages)
            merged=folder/app.combined_pdf_name(chapters)
            self.assertGreaterEqual(app.merge_chapter_pdfs(cache,chapters,merged),2)
            app.record_merged(folder,chapters,merged)
            self.assertTrue(app.merged_completed(folder,chapters,merged))
            shutil.rmtree(cache)
            self.assertEqual([p.name for p in folder.glob('*.pdf')],[merged.name])
            self.assertTrue(app.merged_completed(folder,chapters,merged))
            merged.write_bytes(b'%PDF-1.5 changed')
            self.assertFalse(app.merged_completed(folder,chapters,merged))

    def test_export_fail_does_not_leave_partial_pdf(self):
        with tempfile.TemporaryDirectory() as root:
            url='https://cdn.example/1.png'
            blob=fake_mhtml({url:b'corrupt'})
            path=Path(root)/'Chap_001.pdf'
            with self.assertRaises(Exception):
                app.pdf_from_mhtml(blob,[url],path)
            self.assertFalse(path.exists())
            self.assertFalse((Path(root)/'Chap_001.pdf.part').exists())

if __name__ == '__main__':
    unittest.main()
