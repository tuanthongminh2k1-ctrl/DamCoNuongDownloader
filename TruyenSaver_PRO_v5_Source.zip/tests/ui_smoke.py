from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from tkinter import Tk
from PIL import ImageGrab

root=Tk()
app.apply_app_style(root)
ui=app.App(root)
root.update()
example='https://damconuong.cool/truyen/ban-hoc'
items=[{'number':float(i),'url':f'{example}/chapter-{i}'} for i in range(1,11)]
ui._emit('scanned',example,'Bạn Học',items)
ui._drain()
root.update()
assert len(ui.table.get_children())==10
assert len(ui.scan_selection)==10
ui._select_none()
assert len(ui.scan_selection)==0
ui.start_var.set('2');ui.end_var.set('5');ui._select_range()
assert len(ui.scan_selection)==4
ui.theme_var.set('Sáng');ui._change_theme()
root.update()
ui.theme_var.set('Hsin • Moon Fox');ui._change_theme()
root.update()
root.after_cancel(root.after(200,lambda:None)) if False else None
# Capture actual rendered desktop application under xvfb
try:
 im=ImageGrab.grab(bbox=(0,0,1100,950))
 im.save('/mnt/data/TruyenSaver_PRO_v4_preview.png')
except Exception as e:
 print('Screenshot unavailable:',e)
print('UI_SMOKE_OK',len(ui.scan_selection),ui.theme_var.get(),app.VERSION)
ui.busy=False
ui._close()
