"""Manual smoke: abort a pending browser page.goto without waiting for timeout."""
import threading,time,sys
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from playwright.sync_api import sync_playwright

class SlowHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        time.sleep(13)
        try:
            self.send_response(200);self.end_headers();self.wfile.write(b'<p>slow</p>')
        except (BrokenPipeError,ConnectionResetError): pass
    def log_message(self,*args):pass

server=ThreadingHTTPServer(('127.0.0.1',0),SlowHandler)
threading.Thread(target=server.serve_forever,daemon=True).start()
engine=app.ChromiumEngine()
try:
    port=engine.ensure()
    started=threading.Event(); done=threading.Event(); result=[]
    def browse():
        try:
            with sync_playwright() as pw:
                browser=pw.chromium.connect_over_cdp(f'http://127.0.0.1:{port}',timeout=20000)
                page=browser.contexts[0].new_page()
                started.set()
                page.goto(f'http://127.0.0.1:{server.server_address[1]}/slow',wait_until='domcontentloaded',timeout=25000)
                result.append('unexpected navigation success')
        except Exception as exc:
            result.append(type(exc).__name__)
        finally: done.set()
    threading.Thread(target=browse,daemon=True).start()
    if not started.wait(5): raise RuntimeError('Chromium did not start navigation')
    time.sleep(0.6)
    begin=time.monotonic()
    engine.abort()
    if not done.wait(7): raise RuntimeError('Browser navigation did not stop promptly')
    elapsed=time.monotonic()-begin
    print(f'Abort completed in {elapsed:.2f} sec; browser result: {result}')
    if elapsed>7 or 'unexpected navigation success' in result: raise RuntimeError('Abort failed')
finally:
    engine.abort(); server.shutdown()
