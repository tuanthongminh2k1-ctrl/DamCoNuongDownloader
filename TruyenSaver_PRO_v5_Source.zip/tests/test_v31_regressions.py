"""v3.1 regressions: 35/35 false negative and global DỪNG."""
import base64
import os
import re
import sys
import tempfile
import threading
import time
import unittest
from concurrent.futures import Future
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
from test_reader_v24 import png


class FakeUi:
    def __init__(self): self.values=[]
    def configure(self, **kw): self.values.append(kw)
    def set(self, value): self.values.append(value)


class FakeBrowser:
    def __init__(self): self.aborted=threading.Event()
    def abort(self): self.aborted.set()


class GlobalStopTests(unittest.TestCase):
    def test_stop_cancels_all_pending_and_aborts_browser(self):
        first,second=Future(),Future()
        stop=threading.Event()
        fake=SimpleNamespace(busy=True,cancel=stop,stop_button=FakeUi(),
                             status_var=FakeUi(),_futures_lock=threading.RLock(),
                             _futures={first,second},browser=FakeBrowser(),log=lambda x:None)
        app.App.stop(fake)
        self.assertTrue(stop.is_set())
        self.assertTrue(first.cancelled())
        self.assertTrue(second.cancelled())
        self.assertTrue(fake.browser.aborted.wait(2.0))

    def test_no_incomplete_mhtml_after_stop(self):
        with tempfile.TemporaryDirectory() as d:
            stop=threading.Event(); stop.set()
            target=Path(d)/'Chap_001.mhtml'
            with self.assertRaises(InterruptedError):
                app.save_atomic_bytes(b'x'*30000,target,stop)
            self.assertFalse(target.exists())
            self.assertFalse((Path(d)/'Chap_001.mhtml.part').exists())

    def test_no_incomplete_pdf_after_stop(self):
        with tempfile.TemporaryDirectory() as d:
            stop=threading.Event(); stop.set()
            with self.assertRaises(InterruptedError):
                app.pdf_from_mhtml(b'invalid',[],Path(d)/'Chap_001.pdf',stop)
            self.assertFalse((Path(d)/'Chap_001.pdf').exists())


class FalseReaderEndTests(unittest.TestCase):
    def test_35_of_35_when_viewport_tail_false(self):
        """Simulate the exact log: all 35/35 images ready but readerEnd false."""
        from playwright.sync_api import sync_playwright
        images=[]
        for i in range(35):
            uri='data:image/png;base64,'+base64.b64encode(png(shade=i+30)).decode('ascii')
            images.append(f'<img src="{uri}" style="display:block;width:280px;height:500px">')
        html='<div class="reading-detail">'+''.join(images)+'</div><div style="height:120000px"></div>'
        js=re.sub(r'const readerEnd=Boolean\(last && top <= innerHeight\+100 && lastBottom >= -100\);',
                  'const readerEnd=false;',app.READER_JS)
        self.assertIn('const readerEnd=false;',js)
        with sync_playwright() as pw:
            kw={'headless':True}
            if sys.platform.startswith('linux') and Path('/usr/bin/chromium').is_file():
                kw['executable_path']='/usr/bin/chromium'; kw['args']=['--no-sandbox']
            browser=pw.chromium.launch(**kw)
            try:
                page=browser.new_page(viewport={'width':900,'height':760})
                page.set_content(html)
                with patch.object(app,'READER_JS',js):
                    result=app.wait_for_reader(page,lambda _:None,threading.Event(),max_seconds=18)
                self.assertEqual(result['total'],35)
                self.assertEqual(len(result['urls']),35)
            finally:
                browser.close()

    def test_stop_check_before_reader_io(self):
        stop=threading.Event();stop.set()
        with self.assertRaises(InterruptedError):
            app.wait_for_reader(None,lambda x:None,stop,max_seconds=5)

if __name__=='__main__': unittest.main()
