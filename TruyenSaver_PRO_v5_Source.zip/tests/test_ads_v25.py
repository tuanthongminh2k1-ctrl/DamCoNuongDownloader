"""Browser regression tests: strip bottom banner ads, preserve comic images."""
import base64
import sys
import tempfile
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path
from playwright.sync_api import sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import (REMOVE_ADS_JS, capture_verified_blob, verify_mhtml, pdf_from_mhtml)
from test_reader_v24 import png


def encoded(shade):
    return 'data:image/png;base64,' + base64.b64encode(png(w=150, h=300, shade=shade)).decode('ascii')


def html_parts(blob):
    message=BytesParser(policy=policy.default).parsebytes(blob)
    return '\n'.join((part.get_payload(decode=True) or b'').decode('utf-8','replace')
                     for part in message.walk() if part.get_content_type() == 'text/html')


class AdCleanTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        options = {'headless':True}
        if sys.platform.startswith('linux') and Path('/usr/bin/chromium').exists():
            options.update(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        cls.browser=cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def new_page(self):
        page=self.browser.new_page(viewport={'width': 1000, 'height': 760})
        art = [encoded(60),encoded(80),encoded(110)]
        ad_img = encoded(18)
        markup = '''<html><body>
          <div class="chapter-content" id="reader">
            <img class="comic" width="700" height="600" src="''' + art[0] + '''">
            <div id="sponsor_box"><img src="''' + ad_img + '''" width="350" height="60"></div>
            <img class="comic" width="700" height="600" src="''' + art[1] + '''">
            <img class="comic" width="700" height="600" src="''' + art[2] + '''">
          </div>
          <div class="randomdock" data-test="FLOATING_BANNER_FOR_ADS"
               style="position:fixed;bottom:0;left:10px;background:#eee;width:350px;height:70px">
            <img src="''' + ad_img + '''" width="300" height="60">
          </div>
          <div class="advert-overlay" data-test="BAD_AD_CONTAINER"><a href="#">click me</a></div>
          <footer><p>CHAPTER_NAVIGATION</p></footer>
        </body></html>'''
        page.set_content(markup,wait_until='domcontentloaded')
        return page, art

    def test_ads_removed_only_from_saved_snapshot(self):
        page, art=self.new_page()
        try:
            blob, check=capture_verified_blob(page, {'urls': art}, lambda _:None, strip_ads=True)
            self.assertTrue(check.ok,check.explanation)
            markup=html_parts(blob)
            self.assertNotIn('FLOATING_BANNER_FOR_ADS', markup)
            self.assertNotIn('BAD_AD_CONTAINER', markup)
            self.assertNotIn('sponsor_box',markup)
            self.assertIn('CHAPTER_NAVIGATION', markup)
            self.assertEqual(verify_mhtml(blob, art).matched, 3)
            with tempfile.TemporaryDirectory() as folder:
                target = Path(folder) / 'Chap_001.pdf'
                page_count = pdf_from_mhtml(blob, art, target)
                self.assertGreaterEqual(page_count, 1)
                self.assertGreater(target.stat().st_size, 1500)
        finally:
            page.close()

    def test_opt_out_preserves_page_ads(self):
        page, art=self.new_page()
        try:
            blob, check=capture_verified_blob(page,{'urls': art},lambda _:None,strip_ads=False)
            self.assertTrue(check.ok)
            markup=html_parts(blob)
            self.assertIn('FLOATING_BANNER_FOR_ADS', markup)
        finally:
            page.close()

    def test_protect_reader_image_inside_unusual_ad_class(self):
        page=self.browser.new_page()
        try:
            src=encoded(90)
            page.set_content('<div class="advert-overlay"><div class="chapter-content">'
                             '<img src="' + src + '" height="500" width="500"></div></div>')
            result=page.evaluate(REMOVE_ADS_JS,[src])
            self.assertEqual(result['removed'],0)
            self.assertEqual(page.locator('img').count(),1)
        finally:
            page.close()


if __name__=='__main__':
    unittest.main()
