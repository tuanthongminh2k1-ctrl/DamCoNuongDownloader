"""Verify seamless digital PDF: original comic images are never split or cropped."""
import base64
from io import BytesIO
import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image, ImageDraw
from pypdf import PdfReader

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import (pdf_from_mhtml, pdf_completed, write_pdf_manifest, merge_chapter_pdfs,
                 combined_pdf_name, write_index_formats)


def make_png(width, height, color):
    image = Image.new('RGB', (width, height), color)
    d = ImageDraw.Draw(image)
    d.rectangle((5, 5, width - 5, min(55, height - 5)), fill=(210, 40, 20))
    output = BytesIO()
    image.save(output, 'PNG')
    return output.getvalue()


def fake_mhtml(images):
    boundary = 'MHTMLTEST23'
    parts = [f'MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="{boundary}"\r\n\r\n',
             f'--{boundary}\r\nContent-Type: text/html; charset="utf-8"\r\n'
             'Content-Location: https://demo.example/chapter-1\r\n\r\n'
             '<html><body><div class="reading-detail">Reader</div></body></html>\r\n']
    for url, binary in images.items():
        parts.append(f'--{boundary}\r\nContent-Type: image/png\r\nContent-Location: {url}\r\n'
                     'Content-Transfer-Encoding: base64\r\n\r\n'
                     + base64.b64encode(binary).decode('ascii') + '\r\n')
    parts.append(f'--{boundary}--\r\n')
    return ''.join(parts).encode('ascii')


class TestPdf(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.chapters = [
            {'number': 1., 'url': 'https://damconuong.cool/truyen/demo/chapter-1'},
            {'number': 2., 'url': 'https://damconuong.cool/truyen/demo/chapter-2'},
        ]
        self.urls = ['https://cdn.example/p1.png', 'https://cdn.example/p2.png']
        self.blob = fake_mhtml({self.urls[0]: make_png(640, 750, 'lightblue'),
                                self.urls[1]: make_png(640, 2900, 'pink'),
                                'https://cdn.example/ad.png': make_png(640, 500, 'yellow')})

    def tearDown(self):
        self.temp.cleanup()

    def test_export_readable_pages_no_ad_and_all_pixels_preserved(self):
        out = self.folder / 'Chap_001.pdf'
        pages = pdf_from_mhtml(self.blob, self.urls, out)
        reader = PdfReader(str(out))
        self.assertEqual(pages, len(reader.pages))
        self.assertGreater(pages, 1)  # Readable height rather than one microscopic page.
        self.assertTrue(all(300 <= float(p.mediabox.width) <= 800 and
                            float(p.mediabox.height) <= 2700 for p in reader.pages))
        # No ad asset: only the 2 story sources, potentially sliced at row boundaries.
        source_images = []
        for pg in reader.pages:
            source_images.extend(pg.images)
        self.assertGreaterEqual(len(source_images), 2)
        widths = []
        total_height = 0
        for picture in source_images:
            im = Image.open(BytesIO(picture.data))
            widths.append(im.width)
            total_height += im.height
        self.assertTrue(all(w == 640 for w in widths))
        self.assertEqual(total_height, 750 + 2900)

    def test_extremely_tall_source_splits_without_dropping_rows(self):
        image_url = 'https://cdn.example/verytall.png'
        blob = fake_mhtml({image_url: make_png(80, 2000, 'green')})
        out = self.folder / 'Tall.pdf'
        count = pdf_from_mhtml(blob, [image_url], out)
        reader = PdfReader(str(out))
        self.assertEqual(count, len(reader.pages))
        self.assertGreater(count, 1)
        self.assertEqual(sum(Image.open(BytesIO(im.data)).height
                             for page in reader.pages for im in page.images), 2000)

    def test_long_chapter_pages_fit_screen(self):
        urls = [f'https://cdn.example/chunk{i}.png' for i in range(3)]
        blob = fake_mhtml({u: make_png(160, 880, 'navy') for u in urls})
        out = self.folder / 'Two_pages.pdf'
        count = pdf_from_mhtml(blob, urls, out)
        pages = PdfReader(str(out)).pages
        self.assertEqual(len(pages), count)
        self.assertGreater(count, 1)
        self.assertTrue(all(float(pg.mediabox.height) <= 2700 for pg in pages))

    def test_missing_image_refuses_pdf(self):
        out = self.folder / 'Missing.pdf'
        with self.assertRaises(ValueError):
            pdf_from_mhtml(self.blob, self.urls + ['https://cdn.example/missing.png'], out)
        self.assertFalse(out.exists())

    def test_corrupt_image_refuses_pdf(self):
        blob = fake_mhtml({self.urls[0]: b'not-image' * 500,
                           self.urls[1]: make_png(640, 500, 'green')})
        out = self.folder / 'Corrupt.pdf'
        with self.assertRaises(Exception):
            pdf_from_mhtml(blob, self.urls, out)
        self.assertFalse(out.exists())
        self.assertFalse((self.folder / 'Corrupt.pdf.part').exists())

    def test_merge_refuses_incomplete(self):
        out = self.folder / 'Chap_001.pdf'
        pages = pdf_from_mhtml(self.blob, self.urls, out)
        write_pdf_manifest(self.folder, '001', self.chapters[0]['url'], out, 2, pages)
        with self.assertRaisesRegex(RuntimeError, '002'):
            merge_chapter_pdfs(self.folder, self.chapters, self.folder / 'Gop.pdf')

    def test_merge_and_index(self):
        for chap in self.chapters:
            n = int(chap['number'])
            out = self.folder / f'Chap_{n:03d}.pdf'
            pages = pdf_from_mhtml(self.blob, self.urls, out)
            write_pdf_manifest(self.folder, f'{n:03d}', chap['url'], out, 2, pages)
            self.assertTrue(pdf_completed(self.folder, f'{n:03d}', chap['url'], out))
        out = self.folder / combined_pdf_name(self.chapters)
        pages = merge_chapter_pdfs(self.folder, self.chapters, out)
        self.assertGreaterEqual(pages, 2)
        self.assertEqual(len(PdfReader(str(out)).pages), pages)
        write_index_formats(self.folder, 'Demo', self.chapters, 'pdf', out)
        index = (self.folder / 'MUC_LUC.html').read_text(encoding='utf8')
        self.assertIn('Chap_001.pdf', index)
        self.assertIn('PDF gộp', index)

    def test_old_pdf_has_to_be_regenerated(self):
        out = self.folder / 'Chap_001.pdf'
        pages = pdf_from_mhtml(self.blob, self.urls, out)
        write_pdf_manifest(self.folder, '001', self.chapters[0]['url'], out, 2, pages)
        self.assertTrue(pdf_completed(self.folder, '001', self.chapters[0]['url'], out))
        import json
        path = self.folder / 'TIEN_DO_PDF.json'
        data = json.loads(path.read_text(encoding='utf8'))
        data['001'].pop('render_version', None)  # Manifest from old A4 converter.
        path.write_text(json.dumps(data), encoding='utf8')
        self.assertFalse(pdf_completed(self.folder, '001', self.chapters[0]['url'], out))

if __name__ == '__main__':
    unittest.main()

class TestArchiveReuse(unittest.TestCase):
    def test_can_rebuild_pdf_from_old_reader_html(self):
        from app import offline_reader_urls, verify_mhtml
        u1, u2, ad = ('https://img.example/001.png', 'https://img.example/002.png', 'https://img.example/ad.png')
        blob = fake_mhtml({u1:make_png(100,150,'red'),u2:make_png(100,150,'blue'),
                           ad:make_png(100,150,'yellow')})
        htmlpart = (f'<html><body><img src="{ad}"><div class="reading-detail">'
                    f'<img src="{u1}"><img data-src="{u2}"></div></body></html>')
        blob=blob.replace(b'<div class="reading-detail">Reader</div>',htmlpart.encode('ascii'))
        extracted = offline_reader_urls(blob, 'https://site.example/chapter1', 2)
        self.assertEqual(extracted, [u1,u2])
        self.assertTrue(verify_mhtml(blob,extracted).ok)
    def test_reject_wrong_count_in_old_archive(self):
        from app import offline_reader_urls
        u = 'https://img.example/001.png'
        blob = fake_mhtml({u:make_png(120,140,'red')}).replace(
           b'<div class="reading-detail">Reader</div>',
           f'<div class="reading-detail"><img src="{u}"></div>'.encode('ascii'))
        self.assertEqual(offline_reader_urls(blob,'https://site.example/chapter1',2),[])
