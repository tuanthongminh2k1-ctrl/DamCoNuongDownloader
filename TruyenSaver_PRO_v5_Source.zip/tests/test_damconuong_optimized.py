"""Regression checks for DamCoNuong-specific improvements (offline fixtures)."""
import sys
import threading
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import app
from test_core import mock_mhtml

SERIES = 'https://damconuong.cool/truyen/tieu-thuyet-a'

class SimplePage:
    def __init__(self):
        self.url=SERIES
        self.eval_count=0
        self.context=None
    def locator(self, selector):
        return self
    def evaluate_all(self, script):
        self.eval_count+=1
        if 'page=2' in self.url:
            return [
                {'href':'/truyen/tieu-thuyet-a/chapter-3','text':'Chap 3'},
                {'href':'/truyen/ngoai-truyen/chapter-9','text':'Chap 9'},
            ]
        links=[{'href':'/truyen/tieu-thuyet-a/chapter-1','text':'Chapter 1'},
               {'href':'?page=2','text':'2'}]
        if self.eval_count > 5:
            links += [{'href':'/truyen/tieu-thuyet-a/chapter-2','text':'Chapter 2'}]
        return links
    def evaluate(self, script):
        return None
    def wait_for_timeout(self, timeout):
        return None

class SimpleApp:
    def __init__(self):
        self.cancel=threading.Event()
        self.logs=[]
    def log(self,line):
        self.logs.append(line)
    def _navigate_to_chapter(self,page,url):
        page.url=url
    _discover_damconuong=app.App._discover_damconuong

class TestDamCoNuong(unittest.TestCase):
    def test_chapter_text_metadata_is_not_included(self):
        anchors=[{'href':'/truyen/tieu-thuyet-a/chapter-1.5',
                  'text':'Chapter 1.5\n 1 năm trước\n24.8K lượt xem'},
                 {'href':'/truyen/tieu-thuyet-a/chapter-2',
                  'text':'Chap 2\n1 năm trước'},
                 {'href':'/truyen/tieu-thuyet-a/chapter-7',
                  'text':'24.8K lượt xem'},
                 {'href':'/truyen/tieu-thuyet-a/chapter-9',
                  'text':'Chapter 9'},
                 {'href':'/truyen/tieu-thuyet-ab/chapter-99','text':'Chapter 99'}]
        self.assertEqual([x['number'] for x in app.extract_chapters(anchors,SERIES)],
                         [1.5,2,7,9])

    def test_only_same_story_paginated_links(self):
        inputs=[{'href':'?page=2','text':'2'},
                {'href':'/truyen/tieu-thuyet-a/page/3','text':'3'},
                {'href':'/truyen/ngoai-truyen?page=4','text':'next'},
                {'href':'https://damconuong.cool.evil.test/truyen/tieu-thuyet-a?page=5','text':'next'},
                {'href':'/page/9','text':'next'},
                {'href':'?page=9999','text':'end'},
                {'href':'?q=chapter','text':'search'}]
        self.assertEqual(set(app.damconuong_chapter_page_links(inputs,SERIES)),{
            'https://damconuong.cool/truyen/tieu-thuyet-a?page=2',
            'https://damconuong.cool/truyen/tieu-thuyet-a/page/3'})

    def test_page_scan_collects_lazy_chapters_and_pagination(self):
        page=SimplePage(); actor=SimpleApp()
        chapters=actor._discover_damconuong(page,SERIES,0,1000)
        self.assertEqual([x['number'] for x in chapters],[1.,2.,3.])
        self.assertTrue(any('2 trang' in s for s in actor.logs))

    def test_host_limit(self):
        self.assertEqual(app.host_download_limit(SERIES,3),1)
        self.assertEqual(app.host_download_limit('https://sayhentai.cx/truyen-a',3),3)
        self.assertFalse(app.is_damconuong('https://damconuong.cool.attacker.test/'))

    def test_snapshot_retries_incomplete_mhtml_on_damconuong(self):
        u1='https://cdn.example/1.png';u2='https://cdn.example/2.png'
        incomplete=mock_mhtml([u1]); complete=mock_mhtml([u1,u2])
        class Session:
            def __init__(self,content):self.content=content
            def send(self,*args,**kwargs):return {'data':self.content.decode('ascii')}
            def detach(self):pass
        class Context:
            count=0
            def new_cdp_session(self,page):
                self.count+=1
                return Session(incomplete if self.count == 1 else complete)
        class Page:
            url=SERIES
            context=Context()
            def evaluate(self,js):return None
            def wait_for_timeout(self,ms):return None
        logs=[]
        blob,check=app.capture_verified_blob(Page(),{'urls':[u1,u2]},logs.append,strip_ads=False)
        self.assertEqual(check.matched,2)
        self.assertTrue(check.ok)
        self.assertEqual(Page.context.count,2)

if __name__=='__main__':unittest.main()

class TestDamCoNuongFailures(unittest.TestCase):
    def test_snapshot_refuses_incomplete_images_after_all_retries(self):
        u1='https://cdn.example/a.png';u2='https://cdn.example/b.png'
        incomplete=mock_mhtml([u1])
        class Session:
            def send(self,*args,**kwargs): return {'data': incomplete.decode('ascii')}
            def detach(self):pass
        class Context:
            count=0
            def new_cdp_session(self,page):
                self.count+=1
                return Session()
        class Page:
            url=SERIES
            context=Context()
            def evaluate(self,script):return None
            def wait_for_timeout(self,t):return None
        with self.assertRaises(RuntimeError):
            app.capture_verified_blob(Page(),{'urls':[u1,u2]},lambda s:None,strip_ads=False)
        self.assertEqual(Page.context.count,3)
