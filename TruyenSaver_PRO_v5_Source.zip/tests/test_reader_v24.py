"""Regression tests for the old 35/35-but-'unstable' false negative."""
import base64
import os
import struct
import sys
import tempfile
import threading
import unittest
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import ready_to_archive, reader_signature, wait_for_reader, capture_verified_blob, save_atomic_bytes, verify_mhtml, pdf_from_mhtml


def png(w=150, h=310, shade=145):
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    raw = b''.join(b'\0' + bytes([shade, 125, 180]) * w for _ in range(h))
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b''))


class ReaderGateTest(unittest.TestCase):
    def test_dynamic_footer_does_not_affect_signature(self):
        a = {'selector': '.reading-detail', 'total': 35, 'missing': 0,
             'images': [{'key': f'ts-{i}', 'src': f'https://cdn.example/{i}.jpg', 'ready': True} for i in range(35)],
             'documentHeight': 90000, 'readerEnd': True}
        b = dict(a, documentHeight=120000)
        self.assertEqual(reader_signature(a), reader_signature(b))
        self.assertTrue(ready_to_archive(a, True, 3.1))
        self.assertFalse(ready_to_archive(a, False, 10))
        self.assertFalse(ready_to_archive(a, True, 1))
        self.assertFalse(ready_to_archive(dict(a, missing=1), True, 10))

    def test_browser_35_loaded_images_but_footer_very_long(self):
        """Reproduce: all reader pictures ready, page bottom below 100kpx footer."""
        from playwright.sync_api import sync_playwright
        images = []
        for i in range(35):
            src = 'data:image/png;base64,' + base64.b64encode(png(shade=40 + i)).decode('ascii')
            images.append(f'<img loading="lazy" style="display:block;width:400px;height:610px" '
                          f'data-src="{src}" src="data:image/svg+xml,%3Csvg%3E%3C/svg%3E" />')
        body = ('<html><body><div class="reading-detail">' + ''.join(images) + '</div>'
                + '<div id="infinite-ad-footer" style="height:120000px"></div></body></html>')
        with sync_playwright() as pw:
            kwargs = {'headless': True}
            if sys.platform.startswith('linux') and Path('/usr/bin/chromium').is_file():
                kwargs['executable_path'] = '/usr/bin/chromium'
                kwargs['args'] = ['--no-sandbox']
            browser = pw.chromium.launch(**kwargs)
            try:
                page = browser.new_page(viewport={'width': 900, 'height': 760})
                page.set_content(body, wait_until='domcontentloaded')
                result = wait_for_reader(page, lambda _: None, threading.Event(), max_seconds=45)
                self.assertEqual(result['total'], 35)
                self.assertEqual(len(result['urls']), 35)
                # Also prove that the NEXT stage can capture these exact resources.
                blob, check = capture_verified_blob(page, result, lambda _: None)
                self.assertTrue(check.ok, check.explanation)
                self.assertEqual(check.matched, 35)
                with tempfile.TemporaryDirectory() as d:
                    target = Path(d) / 'Chap_001.mhtml'
                    save_atomic_bytes(blob, target)
                    self.assertTrue(verify_mhtml(target.read_bytes(), result['urls']).ok)
                    pdf_path = Path(d) / 'Chap_001.pdf'
                    pages = pdf_from_mhtml(blob, result['urls'], pdf_path)
                    self.assertGreaterEqual(pages, 1)
                    self.assertGreater(pdf_path.stat().st_size, 1500)
            finally:
                browser.close()

    def test_broken_image_is_not_marked_complete(self):
        from playwright.sync_api import sync_playwright
        src = 'data:image/png;base64,' + base64.b64encode(png()).decode('ascii')
        markup = ('<html><body><div class="reading-detail">'
                  f'<img src="{src}" style="display:block;width:300px;height:700px">'
                  '<img src="data:image/png;base64,INVALID" style="display:block;width:300px;height:700px">'
                  '</div></body></html>')
        with sync_playwright() as pw:
            kwargs = {'headless': True}
            if sys.platform.startswith('linux') and Path('/usr/bin/chromium').is_file():
                kwargs['executable_path'] = '/usr/bin/chromium'
                kwargs['args'] = ['--no-sandbox']
            browser = pw.chromium.launch(**kwargs)
            try:
                page = browser.new_page(viewport={'width': 900, 'height': 760})
                page.set_content(markup)
                with self.assertRaisesRegex(RuntimeError, 'Không thể xác nhận đủ ảnh'):
                    wait_for_reader(page, lambda _: None, threading.Event(), max_seconds=9)
            finally:
                browser.close()


if __name__ == '__main__':
    unittest.main()
