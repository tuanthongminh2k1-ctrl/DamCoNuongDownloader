import base64
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import (ArchiveCheck, chapter_label, chapter_from_anchor, completed,
                  extract_chapters, normalize_url, sanitize, validate_source,
                  verify_mhtml, write_index, write_manifest_entry)


def mock_mhtml(images, other_images=0):
    boundary='BOUNDARY01'
    lines=[f'MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="{boundary}"\r\n\r\n',
           f'--{boundary}\r\nContent-Type: text/html; charset="utf-8"\r\n'
           'Content-Location: https://site.example/chap\r\n\r\n<html><body>Reader</body></html>\r\n']
    for url in images + [f'https://site.example/ads/logo{x}.png' for x in range(other_images)]:
        lines.append(f'--{boundary}\r\nContent-Type: image/png\r\n'
                     f'Content-Location: {url}\r\nContent-Transfer-Encoding: base64\r\n\r\n'
                     +base64.b64encode(b'\x89PNG\r\n\x1a\n'+b'0'*3000).decode()+'\r\n')
    lines.append(f'--{boundary}--\r\n')
    return ''.join(lines).encode('ascii')


class TestCore(unittest.TestCase):
    def test_domain_allowlist(self):
        self.assertEqual(validate_source('https://damconuong.cool/truyen/ban-hoc'), 'https://damconuong.cool/truyen/ban-hoc')
        self.assertEqual(validate_source('https://sayhentai.cx/abc'), 'https://sayhentai.cx/abc')
        for bad in ['https://evil.invalid/abc','http://damconuong.cool/abc',
                    'https://damconuong.cool.evil.invalid/truyen/abc']:
            with self.assertRaises(ValueError):validate_source(bad)

    def test_chapter_damconuong(self):
        url='https://damconuong.cool/truyen/ban-hoc'
        entries=[{'href':'/truyen/ban-hoc/chapter-2','text':'Chap 2'},
                 {'href':'/truyen/ban-hoc/chapter-1','text':'Chap 1'},
                 {'href':'/truyen/khac/chapter-3','text':'Chap 3'}]
        self.assertEqual([v['number'] for v in extract_chapters(entries,url)],[1,2])

    def test_chapter_sayhentai(self):
        url='https://sayhentai.cx/bo-truyen.html'
        entries=[{'href':'/bo-truyen/chuong-1','text':'Chương 1'},
                 {'href':'/bo-truyen/chuong-2','text':'Chương 2'},
                 {'href':'/bo-truyen-khac/chuong-3','text':'Chương 3'}]
        self.assertEqual([x['number'] for x in extract_chapters(entries,url)],[1,2])

    def test_normalization(self):
        self.assertEqual(normalize_url('https://EXAMPLE.org/one%20two.jpg?x=1#part'),
                         'https://example.org/one two.jpg?x=1')
        self.assertEqual(chapter_label(1),'001')
        self.assertEqual(chapter_label(1.5),'1.5')
        self.assertEqual(sanitize('a:b?c'),'a_b_c')

    def test_mhtml_exact_matches(self):
        urls=['https://site.example/reader/001.jpg', 'https://site.example/reader/002.jpg']
        check=verify_mhtml(mock_mhtml(urls,other_images=2),urls)
        self.assertTrue(check.ok,check)
        self.assertEqual(check.matched,2)
        self.assertEqual(check.extra_images,4)

    def test_mhtml_ads_do_not_count(self):
        urls=['https://site.example/reader/001.jpg', 'https://site.example/reader/002.jpg']
        check=verify_mhtml(mock_mhtml(urls[:1],other_images=5),urls)
        self.assertFalse(check.ok)
        self.assertEqual(check.matched,1)
        self.assertEqual(len(check.missing_urls),1)

    def test_mhtml_reject_bad(self):
        self.assertFalse(verify_mhtml(b'html only', ['https://site.example/1.jpg']).ok)
        self.assertFalse(verify_mhtml(mock_mhtml([]), []).ok)
        self.assertFalse(verify_mhtml(mock_mhtml([]), ['blob:http://site.example/xx']).ok)

    def test_unsafe_old_checkpoint_ignored(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'Chap_001.mhtml'
            f.write_bytes(mock_mhtml(['https://site.example/reader/001.jpg']))
            write_manifest_entry(Path(d), '001','https://site.example/chap/1',f,1,1)
            self.assertTrue(completed(Path(d), '001','https://site.example/chap/1',f))
            self.assertFalse(completed(Path(d), '001','https://site.example/chap/2',f))
            f.write_bytes(b'corruption')
            self.assertFalse(completed(Path(d), '001','https://site.example/chap/1',f))

    def test_offline_index(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d)
            f=folder/'Chap_001.mhtml'
            f.write_bytes(mock_mhtml(['https://site.example/reader/001.jpg']))
            write_manifest_entry(folder, '001', 'https://site.example/chap-1', f,1,1)
            write_index(folder, '<Truyện & tên>',
                        [{'number':1,'url':'https://site.example/chap-1'},
                         {'number':2,'url':'https://site.example/chap-2'}])
            txt=(folder/'MUC_LUC.html').read_text(encoding='utf8')
            self.assertIn('Chap_001.mhtml',txt)
            self.assertNotIn('Chap_002.mhtml',txt)
            self.assertIn('&lt;Truyện &amp; tên&gt;',txt)

    def test_no_keyboard_or_mouse_automation(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf8')
        self.assertNotIn('pyautogui',source)
        self.assertNotIn('send_keys(',source)
        self.assertNotIn('pywinauto',source)

if __name__=='__main__':unittest.main()
