"""Optional real-browser smoke check with a local synthetic comic, no website access.

Run `python tests/real_browser_smoke.py` after system Chromium is available.
"""
import base64
import io
import os
import sys
import tempfile
import threading
from pathlib import Path
from PIL import Image, ImageDraw
from pypdf import PdfReader
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import (ChromiumEngine,wait_for_reader,capture_verified_blob,pdf_from_mhtml,
                 chromium_executable)


def make_data_uri(i):
    img=Image.new('RGB',(300,380),(225-i*8,192+i*2,178+i*2))
    draw=ImageDraw.Draw(img)
    draw.rectangle((12,12,288,45),fill=(95,30,62))
    draw.ellipse((70+i,92,200+i,230),outline=(82,43,50),width=5)
    buff=io.BytesIO();img.save(buff,'PNG')
    return 'data:image/png;base64,'+base64.b64encode(buff.getvalue()).decode()


def main():
    engine=ChromiumEngine()
    try:
        port=engine.ensure(visible=False)
        with sync_playwright() as playwright:
            browser=playwright.chromium.connect_over_cdp(f'http://127.0.0.1:{port}',timeout=15000)
            page=browser.contexts[0].new_page()
            pics=[make_data_uri(i) for i in range(6)]
            markup=''.join(f'<img src="{x}" style="display:block;width:300px" />' for x in pics)
            page.set_content('''<html><body style="margin:0"><header><img src="data:image/svg+xml,%3Csvg%3E%3C/svg%3E"></header>
                 <div class="reading-detail">'''+markup+'''</div>
                 <div id="big-footer" style="height:150000px"></div>
                 <div class="banner" style="position:fixed;bottom:0;left:0;width:340px;height:45px;background:red"><img src="data:image/svg+xml,%3Csvg%3E%3C/svg%3E"></div>
                 </body></html>''',wait_until='domcontentloaded')
            info=wait_for_reader(page,lambda x:print('LOG',x),threading.Event(),max_seconds=30)
            blob,check=capture_verified_blob(page,info,lambda x:print('LOG',x),strip_ads=True)
            assert check.ok and check.expected==6,(check.ok,check.expected,check.missing_urls)
            with tempfile.TemporaryDirectory() as tmp:
                archive=Path(tmp)/'Chap_001.mhtml'
                archive.write_bytes(blob)
                output=Path(tmp)/'Chap_001.pdf'
                pages=pdf_from_mhtml(archive.read_bytes(),info['urls'],output)
                doc=PdfReader(str(output))
                assert pages>=2,(pages,len(doc.pages))
                assert all(float(pg.mediabox.width)==720 and float(pg.mediabox.height)<=2500 for pg in doc.pages)
                print('REAL_BROWSER_SMOKE_OK',check.expected,'images',pages,'PDF pages',len(blob),'MHTML bytes')
            page.close()
    finally:
        engine.close()

if __name__=='__main__':main()
