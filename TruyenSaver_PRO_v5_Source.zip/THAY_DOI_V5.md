# Các thay đổi của v5

- Tách `chapter_v5.py` làm bộ ghi ảnh theo giao dịch từng chương; manifest SHA-256.
- Thay `_download` ở giao diện bằng hàng đợi **một chương mỗi lần**, dừng ở lần thất bại đầu tiên.
- Thêm `discover_reader_urls_v5` (tải dần và ổn định danh sách ảnh của vùng đọc).
- Thêm `fetch_chapter_image_v5` sử dụng phiên Chromium hiện có và Referer.
- Thêm `pdf_from_local_images` tạo PDF từ ảnh đã kiểm tra.
- Thêm trình đọc HTML offline local và mục lục cập nhật theo chương hoàn thành.
- Hỗ trợ chuyển từ cấu hình v4 nhưng không dùng lại đường xuất MHTML cũ.
- Thêm 10 test v5, mở rộng smoke test trình duyệt khi tạo EXE.
