# TruyenSaver PRO v5 – TẢI THEO TỪNG CHAP, XÁC MINH ẢNH TRƯỚC

## Các khác biệt so với v4.1

- **Không lưu MHTML làm đầu vào cho PDF**. Ảnh gốc được tải riêng từng file.
- **Một lần xử lý đúng một chap.** Chap chưa đủ ảnh sẽ dừng toàn bộ hàng đợi.
- Quét ảnh trong vùng đọc bằng Chromium, cố gắng kích hoạt lazy-loading và đợi danh sách ổn định.
- Mỗi ảnh được xác thực bằng Pillow (đọc toàn bộ pixels), kích thước và **SHA-256**.
- Mỗi ảnh lỗi được thử lại tối đa **5 lần sau lượt đầu** (6 lượt tất cả).
- Ảnh đã lưu hợp lệ được tái sử dụng khi chạy lại; ảnh lỗi phải tải lại.
- Không tạo HTML hoặc PDF khi vẫn có ảnh thiếu/hỏng.
- HTML offline chỉ dùng đường dẫn ảnh local `images/0001.jpg`, không phụ thuộc website.
- PDF dựng từ ảnh local, giữ thứ tự, chia ảnh dài thành trang dễ đọc, không cắt mất hàng pixel.
- Giao diện tiếng Việt, nguồn truyện giữ 3 host: damconuong.cool, sayhentai.cx, hentaicube.xyz.

## Thư mục đầu ra ví dụ

```
Thư_mục_bạn_chọn/
  damconuong.cool/
    Tên_truyện/
      MUC_LUC.html
      BAO_CAO.txt
      Chap_001/
        progress.json
        DOC_OFFLINE.html
        Chap_001.pdf       (nếu chọn xuất PDF)
        images/
          0001.webp
          0002.jpg
          0003.png
      Chap_002/
        ...
```

`progress.json` lưu trạng thái `complete` hoặc `incomplete`, số ảnh và mã SHA-256 từng ảnh.
Nếu tải dở: giữ nguyên `images/` và file tiến độ, mở lại và bấm BẮT ĐẦU TẢI.

## Cách sử dụng

1. Mở `TruyenSaver_PRO_v5.exe` **trong bộ thư mục Portable đã giải nén đầy đủ**.
2. Dán URL trang TRUYỆN vào ô nguồn. Phần mềm tự quét các URL chương trong trang truyện.
3. Bấm QUÉT DANH SÁCH CHAP; chọn một hoặc vài chap cần tải để thử trước.
4. Chọn `Ảnh + HTML + PDF` (mặc định), `Ảnh + HTML offline`, hoặc `Ảnh + PDF`.
5. Bấm BẮT ĐẦU TẢI. Ứng dụng xử lý tuần tự từng chap, mỗi chap có báo cáo.
6. Dùng ĐỌC OFFLINE để mở `MUC_LUC.html` hoặc mở `Chap_001/DOC_OFFLINE.html`.

Để giữ trải nghiệm xem trực tiếp như web: mở file `DOC_OFFLINE.html` trong trình duyệt,
phóng to vừa chiều rộng cửa sổ. PDF có chiều rộng trang đồng nhất theo tỷ lệ ảnh.

### Những điều cần biết

- **Chưa kiểm thử được việc tải trực tiếp cả ba website từ máy Windows của người dùng.**
  Các trang có thể chặn truy cập/Cloudflare, thay đổi cấu trúc hoặc chứa ảnh không thể lấy bằng session.
- Không có phần mềm nào bảo đảm 100% danh sách ảnh web có khi website cố ý phân trang động
  hoặc tải ảnh sau khi người dùng xác minh. V5 cố gắng xác nhận cuối vùng đọc và danh sách ổn định;
  nếu chưa xác nhận được, sẽ báo lỗi thay vì xuất file thiếu.
- Không tự vượt Cloudflare hay CAPTCHA. Hãy đăng nhập/xác minh một cách hợp lệ nếu website yêu cầu.
- Cần thử trực tiếp ít nhất một chap DamCoNuong, SayHentai, HentaiCube trên Windows
  trước khi coi kết nối từng website là đã được xác thực.

## Tạo EXE trên GitHub (không cần Python trên máy người dùng)

1. Đưa file **`TruyenSaver_PRO_v5_Source.zip`** vào thư mục gốc repository trên GitHub;
   KHÔNG giải nén. Nếu file cũ v4.1 còn đó thì cũng không sao.
2. Mở/tạo `.github/workflows/build-windows.yml` và **thay toàn bộ nội dung**
   bằng file `BUILD_GITHUB_V5.yml` được cung cấp riêng.
3. Commit → Actions → `TruyenSaver PRO v5 - Verified Chapters - Windows` → Run workflow.
4. Nếu thành công: tải Artifacts `TruyenSaver-PRO-v5-Windows-Portable`, giải nén
   **toàn bộ thư mục** và nhấp đúp `TruyenSaver_PRO_v5.exe`.

Mã nguồn trong ZIP đã kèm `.github/workflows/build-windows.yml` cho người muốn clone đầy đủ.

## Kiểm thử đã thực hiện

- `python -m unittest discover -s tests -p 'test_*.py'` – **78/78 PASS** tại môi trường phát triển.
- Bộ test mới bao gồm tải đủ 3 ảnh, PDF + HTML, thất bại giữa chap, resume không tải lại ảnh hợp lệ,
  checksum chống dùng ảnh hỏng, STOP và bảo đảm hàng đợi không chạy chap tiếp khi chap trước lỗi.
- **Chưa chạy exe trên Windows tại đây.** Workflow GitHub sẽ kiểm tra EXE cùng Chromium tích hợp.
