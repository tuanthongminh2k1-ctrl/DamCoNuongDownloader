# TruyenSaver PRO v5.1 – ĐỔI TÊN MIỀN & ƯU TIÊN ẢNH GỐC

## Điểm thay đổi so với v5.0

1. **Đổi tên miền ngay trong EXE**: nhấn **⚙ ĐỔI TÊN MIỀN** gần bộ chọn giao diện. Mỗi nguồn DamCoNuong / SayHentai / HentaiCube có một ô riêng. Nhập tên miền mới, nhấn **LƯU TÊN MIỀN**. Không cần build lại EXE mỗi lần đổi tên miền.
2. Tên miền lưu trong `%APPDATA%\TruyenSaverChromium\settings_v5.json` dưới khóa `site_domains`. Khi khởi động lần sau, ứng dụng tự đọc lại cấu hình.
3. **Link truyện ở tên miền gốc** được tự chuyển sang tên miền mới khi quét/tải. Path và query giữ nguyên. Không đổi link từ các website không thuộc 3 nguồn.
4. Chỉ chấp nhận HTTPS và tên miền hợp lệ. Tên miền mới là máy chủ do người dùng tin tưởng chọn; không nhập tài khoản, cổng, địa chỉ IP, hay đường dẫn chương vào ô tên miền.
5. **Tải ảnh gốc là chính**, không có bước cân lại kích thước hoặc ép ảnh về 1200px. Định dạng mặc định `Ảnh + HTML offline`: giữ nguyên file ảnh gốc theo thứ tự và tạo trình đọc không cần mạng.
6. Nếu chọn PDF, mỗi ảnh nguyên gốc được đặt lên **một trang PDF có cùng tỷ lệ/kích thước** (1 px tương ứng 1 pt, không ép độ rộng cố định, không gộp nhiều ảnh vào một trang). Ảnh có chiều cao hoặc rộng quá 14.000 px được chia thành các phần nối tiếp **không bỏ pixel** để tránh giới hạn định dạng PDF. File ảnh nguồn luôn giữ nguyên byte.
7. Vẫn giữ 1 chap mỗi lần, retry 5 lần/ảnh, SHA-256 và dừng hàng đợi nếu chap chưa đủ ảnh.

## Cách dùng

1. Giải nén **toàn bộ** artifact Portable và mở `TruyenSaver_PRO_v5_1.exe`.
2. Nếu cần đổi tên miền: **⚙ ĐỔI TÊN MIỀN** → nhập ví dụ `https://ten-mien-moi.com` → **LƯU TÊN MIỀN**. Dùng tên miền có quyền truy cập hợp lệ; các ví dụ không phải tên miền thực đã xác minh.
3. Dán URL của bộ truyện vào ô nguồn → **QUÉT DANH SÁCH CHAP** → chọn chap.
4. Chọn `Ảnh + HTML offline` (khuyến nghị để ưu tiên lưu đủ ảnh) hoặc thêm PDF tùy nhu cầu.
5. Bấm **BẮT ĐẦU TẢI**; nếu lỗi, phần mềm dừng ở chap hiện tại và giữ ảnh đã hoàn thành để tải tiếp.
6. Mở `Chap_XXX/DOC_OFFLINE.html` để xem như website; ảnh nằm trong `Chap_XXX/images/`, file `progress.json` lưu tiến độ.

> Giới hạn: đổi tên miền chỉ có hiệu quả nếu trang mới vẫn giữ cấu trúc lấy chương và ảnh tương thích. Đổi tên miền không vượt xác minh Cloudflare, không khắc phục việc trang chặn truy cập tự động hoặc thay đổi cấu trúc HTML. Không thể bảo đảm ứng dụng nhận ra mọi ảnh nếu trang web không hiển thị chúng khi quét.

## Đưa lên GitHub và tạo EXE

1. Tải đúng file `TruyenSaver_PRO_v5_1_Source.zip` vào **thư mục gốc** repository (không giải nén). Có thể xóa `TruyenSaver_PRO_v5_Source.zip` cũ để tránh nhầm, nhưng không bắt buộc.
2. Chỉnh `.github/workflows/build-windows.yml` và dán toàn bộ nội dung file `BUILD_GITHUB_V5_1.yml` đi kèm gói triển khai.
3. Commit changes → Actions → **TruyenSaver PRO v5.1 - Domain Settings and Original Images - Windows** → Run workflow.
4. Nếu build thành công, tải artifact `TruyenSaver-PRO-v5_1-Windows-Portable` → giải nén → mở `TruyenSaver_PRO_v5_1.exe`.

## Kiểm thử

Các bài kiểm thử tự động bao gồm cấu hình tên miền an toàn, đổi 3 nguồn, tự chuyển link gốc, giữ độ rộng/chiều cao trang PDF bằng kích thước pixel gốc, không mất hàng pixel trên ảnh cực dài, lưu ảnh và tiếp tục tải. Đây là kiểm thử mã nguồn/mẫu **không phải** xác nhận ba website hiện đều tải thành công. Chưa biên dịch/kiểm thử EXE Windows trong môi trường này.
