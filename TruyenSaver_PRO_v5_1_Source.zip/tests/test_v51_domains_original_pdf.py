"""v5.1 safety and feature tests: user-editable domains and native-size PDF."""
from __future__ import annotations
import io
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image
from pypdf import PdfReader
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app


class DomainConfigTests(unittest.TestCase):
    def setUp(self):
        self.old = app.get_site_domains()
        self.addCleanup(app.set_site_domains, self.old)
        app.set_site_domains()

    def test_save_three_new_domains_and_old_urls_automatically_migrate(self):
        mapping = {'DamCoNuong':'truyenmoi.vn',
                   'SayHentai':'https://sayhentai-new.com/',
                   'HentaiCube':'cube-new.net'}
        configured = app.set_site_domains(mapping)
        self.assertEqual(configured['DamCoNuong'], 'truyenmoi.vn')
        self.assertEqual(configured['SayHentai'], 'sayhentai-new.com')
        link='https://damconuong.cool/truyen/abc/chapter-3?page=4'
        self.assertEqual(app.validate_source(link),
                         'https://truyenmoi.vn/truyen/abc/chapter-3?page=4')
        self.assertEqual(app.validate_source('https://truyenmoi.vn/truyen/abc'),
                         'https://truyenmoi.vn/truyen/abc')
        self.assertTrue(app.is_damconuong('https://truyenmoi.vn/truyen/abc'))
        self.assertFalse(app.is_damconuong('https://sayhentai-new.com/truyen/abc'))
        self.assertEqual(app.validate_source('https://sayhentai.cx/truyen-a.html'),
                         'https://sayhentai-new.com/truyen-a.html')

    def test_validation_prevents_bad_hosts_and_unsafe_origins(self):
        for invalid in ('', 'http://example.com', 'https://user:pass@example.com',
                        'https://example.com:8989', 'https://example.com/path',
                        'example.com?x=1', '127.0.0.1', 'localhost', 'app.local',
                        'https://example.com#frag', 'https://example.com.evil.com/abc'):
            with self.subTest(invalid=invalid):
                if invalid == 'https://example.com.evil.com/abc':
                    # Not a valid *domain value* since it is a URL with a path.
                    pass
                with self.assertRaises((ValueError, TypeError)):
                    app.parse_site_domain(invalid)
        with self.assertRaises(ValueError):
            app.validate_source('https://damconuong.cool.attacker.com/truyen')
        with self.assertRaises(ValueError):
            app.validate_source('http://damconuong.cool/truyen')
        with self.assertRaises(ValueError):
            app.validate_source('https://damconuong.cool:9000/truyen')
        with self.assertRaises(ValueError):
            app.set_site_domains({'DamCoNuong':'same.net','SayHentai':'same.net'})
        with self.assertRaises(ValueError):
            app.set_site_domains({'DamCoNuong':'sayhentai.cx'})
        self.assertEqual(app.get_site_domains()['DamCoNuong'], 'damconuong.cool')

    def test_fields_use_updated_link_without_requiring_exe_rebuild(self):
        from types import SimpleNamespace
        app.set_site_domains({'DamCoNuong': 'damco-mirror.org'})
        class Field:
            def __init__(self, x): self.x=x
            def get(self): return self.x
        fake=SimpleNamespace(
            links=SimpleNamespace(get=lambda *args:'https://damconuong.cool/truyen/a'),
            start_var=Field('1'), end_var=Field('3'),
            folder_var=Field(tempfile.gettempdir()),
            format_var=Field('Ảnh + HTML offline'), workers_var=Field('1'),
            ad_free_var=Field(True), _save_settings=lambda:None)
        result=app.App._fields(fake)
        self.assertEqual(result[0], ['https://damco-mirror.org/truyen/a'])
        self.assertEqual(result[4], 'images_html')


class NativePdfTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def create_image(self, name, w, h):
        p=self.root/name
        Image.new('RGB',(w,h),(31,92,183)).save(p)
        return p

    def test_pdf_keeps_original_size_and_byte_identical_source(self):
        images=[self.create_image('001.png',135,210),
                self.create_image('002.png',320,660)]
        before=[p.read_bytes() for p in images]
        pdf=self.root/'chap.pdf'
        n=app.pdf_from_local_images(images,pdf)
        self.assertEqual(n,2)
        pages=PdfReader(str(pdf)).pages
        self.assertEqual([(int(pg.mediabox.width),int(pg.mediabox.height))
                          for pg in pages],[(135,210),(320,660)])
        self.assertEqual([p.read_bytes() for p in images],before)

    def test_unusually_tall_page_slices_without_resizing_or_missing_rows(self):
        image=self.create_image('tall.png',61,14032)
        pdf=self.root/'tall.pdf'
        self.assertEqual(app.pdf_from_local_images([image],pdf),2)
        pages=PdfReader(str(pdf)).pages
        self.assertEqual([(int(pg.mediabox.width),int(pg.mediabox.height))
                          for pg in pages],[(61,14000),(61,32)])
        self.assertEqual(sum(int(pg.mediabox.height) for pg in pages),14032)


if __name__=='__main__': unittest.main()
