"""Keep even very thin comic panels; reject broken payloads but not dimensions."""
import io
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path

from PIL import Image
from pypdf import PdfReader

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
from chapter_v5 import SequentialChapter, check_image, check_saved_image


def png(w, h):
    out=io.BytesIO()
    Image.new('RGB',(w,h),(32,88,177)).save(out,format='PNG')
    return out.getvalue()


class TinyImagesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder=Path(self.tmp.name)/'Chap_030'
        self.urls=['https://example.com/001.png','https://example.com/002.png']
        self.payload={self.urls[0]:png(950,1),self.urls[1]:png(1,1)}
        self.logs=[]

    def store(self):
        return SequentialChapter('https://damconuong.cool/chap-30',self.folder,
                                 stop=threading.Event(),log=self.logs.append)

    def test_tiny_images_are_valid_originals_and_cacheable(self):
        self.assertEqual((check_image(png(950,1)).width,check_image(png(950,1)).height),(950,1))
        self.assertEqual((check_image(png(1,1)).width,check_image(png(1,1)).height),(1,1))
        count,pages=self.store().run(self.urls, lambda url:self.payload[url],
                                     chapter_title='Chap 30')
        self.assertEqual((count,pages),(2,0))
        manifest=json.loads((self.folder/'progress.json').read_text('utf-8'))
        self.assertEqual(manifest['status'],'complete')
        self.assertEqual(len(manifest['warnings']),2)
        for item in manifest['items']:
            image_file=self.folder/'images'/item['file']
            self.assertEqual(image_file.read_bytes(),self.payload[item['url']])
            self.assertTrue(check_saved_image(image_file,item))
        self.assertIn('0001.png',(self.folder/'DOC_OFFLINE.html').read_text('utf-8'))
        self.assertTrue(any('LƯU Ý' in message for message in self.logs))
        called=[]
        self.store().run(self.urls, lambda url:called.append(url))
        self.assertEqual(called,[])

    def test_pdf_with_950_by_1_image_does_not_resample(self):
        path=self.folder/'source.png'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(self.payload[self.urls[0]])
        pdf=self.folder/'thin.pdf'
        self.assertEqual(app.pdf_from_local_images([path],pdf),1)
        page=PdfReader(str(pdf)).pages[0]
        self.assertEqual((float(page.mediabox.width),float(page.mediabox.height)),(950.,1.))
        self.assertEqual(path.read_bytes(),self.payload[self.urls[0]])

    def test_malformed_image_is_still_rejected(self):
        for raw in (b'',b'<html>Cloudflare 403</html>',png(950,1)[:-10]):
            with self.subTest(raw=raw[:10]):
                with self.assertRaises(Exception):
                    check_image(raw)

    def test_reader_does_not_discard_small_natural_dimensions(self):
        self.assertIn('i.naturalWidth>0&&i.naturalHeight>0',app.READER_JS)
        self.assertNotIn('i.naturalHeight>=32',app.READER_JS)
        self.assertNotIn('i.width>=16||i.height>=16',app.READER_JS)

if __name__=='__main__':
    unittest.main()
