"""TruyenSaver PRO v5: verified, resumable, *single-chapter* image pipeline.

Deliberately independent of Playwright, Tk and PDF libraries to permit deterministic
unit tests. A chapter is complete only after its local files and requested
exports have been verified; existing valid images are reused on retry.
"""
from __future__ import annotations

import base64
import hashlib
import html
import io
import json
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Sequence
from urllib.parse import unquote_to_bytes, urlsplit


class ChapterIncomplete(RuntimeError):
    """A chapter is incomplete; earlier valid images remain on disk."""


@dataclass(frozen=True)
class ImageMeta:
    extension: str
    width: int
    height: int
    sha256: str
    size: int


def check_image(raw: bytes) -> ImageMeta:
    """Decode every pixel to reject corrupt bytes, NOT valid tiny images."""
    from PIL import Image, ImageOps
    if not raw or len(raw) > 120 * 1024 * 1024:
        raise ValueError('Ảnh rỗng hoặc vượt giới hạn 120 MB')
    with Image.open(io.BytesIO(raw)) as obj:
        fmt = (obj.format or '').upper()
        obj.verify()
    with Image.open(io.BytesIO(raw)) as obj:
        obj.load()
        w, h = ImageOps.exif_transpose(obj).size
    # A legitimate source may contain 950x1 separators or tiny comic panels.
    # Dimensions alone cannot prove an image is a placeholder: keep its bytes.
    if w <= 0 or h <= 0:
        raise ValueError('Ảnh có kích thước không hợp lệ')
    ext = {'JPEG': '.jpg', 'PNG': '.png', 'WEBP': '.webp', 'GIF': '.gif',
           'BMP': '.bmp', 'TIFF': '.tif', 'AVIF': '.avif'}.get(fmt)
    if ext is None:
        raise ValueError(f'Không hỗ trợ định dạng ảnh: {fmt}')
    return ImageMeta(ext, w, h, hashlib.sha256(raw).hexdigest(), len(raw))


def check_saved_image(file: Path, entry: dict) -> bool:
    """Resume only when file contents genuinely match recorded SHA-256."""
    try:
        if not file.is_file():
            return False
        raw = file.read_bytes()
        meta = check_image(raw)
        return (meta.sha256 == entry.get('sha256')
                and meta.width == entry.get('width')
                and meta.height == entry.get('height')
                and meta.size == entry.get('size'))
    except (OSError, ValueError, RuntimeError):
        return False


def atomic_write_bytes(target: Path, content: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.part')
    try:
        with tmp.open('wb') as out:
            out.write(content)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(target: Path, obj: dict) -> None:
    atomic_write_bytes(target, json.dumps(obj, ensure_ascii=False, indent=2).encode('utf-8'))


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def get_data_image(uri: str) -> bytes:
    """Decode a bounded image data URL; `blob:` must be obtained by the browser."""
    prefix, sep, payload = uri.partition(',')
    if not sep or not prefix.startswith('data:image/'):
        raise ValueError('Không phải đường dẫn ảnh data: hợp lệ')
    if len(payload) > 160 * 1024 * 1024:
        raise ValueError('Data URL quá lớn')
    return (base64.b64decode(payload, validate=True)
            if ';base64' in prefix.lower() else unquote_to_bytes(payload))


def image_export_html(entries: Sequence[dict], chapter_title: str) -> bytes:
    """Only local file URLs; no remote images, scripts, adverts or blank slots."""
    lines = []
    for item in entries:
        filename = item['file']
        if not re.fullmatch(r'\d{3,5}\.(?:jpg|png|webp|gif|bmp|tif|avif)', filename, re.I):
            raise ValueError('Tên file ảnh không hợp lệ')
        lines.append(f'<img src="images/{html.escape(filename, quote=True)}" '
                     f'alt="Trang {int(item["index"])}" loading="eager" decoding="async">')
    doc = ('<!doctype html><html lang="vi"><head><meta charset="utf-8">'
           '<meta name="viewport" content="width=device-width,initial-scale=1">'
           f'<title>{html.escape(chapter_title)}</title>'
           '<style>*{box-sizing:border-box}html,body{margin:0;background:#121212;color:#eee}'
           'body{font:16px Segoe UI,Arial,sans-serif}main{width:min(100%,1200px);margin:auto}'
           'h1{font-size:17px;text-align:center;margin:20px 4px}'
           'img{display:block;width:100%;height:auto;margin:0;padding:0;border:0}'
           '</style></head><body><main>'
           f'<h1>{html.escape(chapter_title)}</h1>' + ''.join(lines) + '</main></body></html>')
    return doc.encode('utf-8')


def write_series_index(dest: Path, title: str, chapters: list[tuple[str, str]]) -> None:
    """Index only chapters that have a locally verified HTML reader."""
    links = []
    for chapter_no, relative in chapters:
        if not (dest / relative).is_file():
            continue
        links.append(f'<li><a href="{html.escape(relative, quote=True)}">'
                     f'Chap {html.escape(chapter_no)}</a></li>')
    page = ('<!doctype html><html lang="vi"><meta charset="utf-8">'
            f'<title>{html.escape(title)}</title><style>body{{background:#141414;color:#eee;'
            'font:18px Segoe UI,Arial;max-width:800px;margin:2em auto;padding:1em}'
            'a{color:#9dcaff}li{margin:12px}</style>'
            f'<h1>{html.escape(title)}</h1><ol>{"".join(links)}</ol></html>')
    atomic_write_bytes(dest / 'MUC_LUC.html', page.encode('utf-8'))


class SequentialChapter:
    """Save one chapter transactionally, with at most five *retries* per image."""

    def __init__(self, chapter_url: str, folder: Path, *, stop,
                 log: Callable[[str], None], retry_count: int = 5,
                 sleep: Callable[[float], None] = time.sleep):
        self.url = chapter_url
        self.folder = Path(folder)
        self.stop = stop
        self.log = log
        self.retry_count = retry_count
        self.sleep = sleep
        self.manifest = self.folder / 'progress.json'

    def _stop_if_requested(self):
        if self.stop.is_set():
            raise InterruptedError('Đã dừng; ảnh hợp lệ đã lưu để tải tiếp')

    def _pause(self, delay: float):
        # Poll so the UI STOP button is responsive while waiting for retries.
        end = time.monotonic() + delay
        while time.monotonic() < end:
            self._stop_if_requested()
            self.sleep(min(.15, max(0., end - time.monotonic())))

    def run(self, urls: Sequence[str], fetch: Callable[[str], bytes], *,
            make_pdf: Callable[[list[Path], Path, object], int] | None = None,
            chapter_title: str = 'Chương truyện') -> tuple[int, int]:
        self._stop_if_requested()
        urls = [str(u).strip() for u in urls]
        if not urls or any(not u for u in urls):
            raise ChapterIncomplete('Chưa xác định được danh sách ảnh đầy đủ')
        if len(urls) > 2500:
            raise ChapterIncomplete('Danh sách ảnh quá lớn, cần kiểm tra lại vùng đọc')
        self.folder.mkdir(parents=True, exist_ok=True)
        images = self.folder / 'images'
        images.mkdir(parents=True, exist_ok=True)
        prior = load_json(self.manifest)
        prior_items = prior.get('items', []) if prior.get('chapter_url') == self.url else []
        if not isinstance(prior_items, list):
            prior_items = []
        old = {x.get('index'): x for x in prior_items if isinstance(x, dict)}
        state = {'schema': 1, 'chapter_url': self.url,
                 'expected': len(urls), 'status': 'incomplete', 'items': [],
                 'warnings': [],
                 'last_error': '', 'updated': time.strftime('%Y-%m-%d %H:%M:%S')}
        # A stale exported PDF must not survive an altered chapter image list.
        preview = self.folder / 'DOC_OFFLINE.html'
        pdf = self.folder / (self.folder.name + '.pdf')
        prior_urls = prior.get('urls')
        if prior_urls != urls:
            preview.unlink(missing_ok=True)
            pdf.unlink(missing_ok=True)
        state['urls'] = list(urls)
        atomic_json(self.manifest, state)
        staged = []
        try:
            for index, url in enumerate(urls, 1):
                self._stop_if_requested()
                existing = old.get(index, {})
                name = existing.get('file', '')
                if (existing.get('url') == url and
                        re.fullmatch(r'\d{3,5}\.(?:jpg|png|webp|gif|bmp|tif|avif)', name, re.I) and
                        check_saved_image(images / name, existing)):
                    self.log(f'    Ảnh {index}/{len(urls)}: đã có, kiểm tra SHA-256 đạt.')
                    entry = dict(existing)
                else:
                    last_exc = None
                    for attempt in range(self.retry_count + 1):
                        self._stop_if_requested()
                        try:
                            raw = fetch(url)
                            meta = check_image(raw)
                            filename = f'{index:04d}{meta.extension}'
                            target = images / filename
                            atomic_write_bytes(target, raw)
                            entry = {'index': index, 'url': url, 'file': filename,
                                     'sha256': meta.sha256, 'width': meta.width,
                                     'height': meta.height, 'size': meta.size}
                            if not check_saved_image(target, entry):
                                raise ValueError('Ảnh tải về không khớp SHA-256')
                            break
                        except InterruptedError:
                            raise
                        except Exception as exc:
                            last_exc = exc
                            self.log(f'    Ảnh {index}/{len(urls)} lỗi lần {attempt + 1}/'
                                     f'{self.retry_count + 1}: {exc}')
                            if attempt < self.retry_count:
                                self._pause(min(6., .6 * (2 ** attempt)))
                    else:
                        raise ChapterIncomplete(
                            f'Ảnh {index}/{len(urls)} thất bại sau {self.retry_count+1} lượt: {last_exc}')
                staged.append(entry)
                if min(entry['width'], entry['height']) < 32:
                    warning = (f'Ảnh {index}/{len(urls)} nhỏ '
                               f"({entry['width']}x{entry['height']}): đã lưu nguyên gốc; "
                               'cần xem lại nếu trang offline bị thiếu nội dung.')
                    state['warnings'].append({'index': index,
                                              'width': entry['width'],
                                              'height': entry['height']})
                    self.log('    LƯU Ý – ' + warning)
                state['items'] = staged.copy()
                atomic_json(self.manifest, state)
                self.log(f'    Đã xác minh {index}/{len(urls)} ảnh.')
            # Confirm saved bytes once more. URLs from the reader must match order.
            files = [images / x['file'] for x in staged]
            if len(files) != len(urls) or any(not check_saved_image(file, item)
                                              for file, item in zip(files, staged)):
                raise ChapterIncomplete('Có ảnh sai hoặc hỏng sau khi lưu')
            self._stop_if_requested()
            atomic_write_bytes(preview, image_export_html(staged, chapter_title))
            if make_pdf is not None:
                pages = make_pdf(files, pdf, self.stop)
                if not pdf.is_file() or pdf.stat().st_size < 1500 or pages < 1:
                    raise ChapterIncomplete('Không xác nhận được file PDF đã tạo')
            self._stop_if_requested()
            state['status'] = 'complete'
            state['verified'] = len(urls)
            state['last_error'] = ''
            atomic_json(self.manifest, state)
            return len(files), (pages if make_pdf is not None else 0)
        except (Exception, InterruptedError) as exc:
            state['status'] = 'incomplete'
            state['last_error'] = str(exc)
            atomic_json(self.manifest, state)
            # An incomplete chapter may still have a prior complete HTML/PDF.
            # Never present such outputs as a verified current download.
            preview.unlink(missing_ok=True)
            pdf.unlink(missing_ok=True)
            raise
