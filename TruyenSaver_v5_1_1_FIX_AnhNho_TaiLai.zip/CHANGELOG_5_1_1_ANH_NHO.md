# TruyenSaver PRO v5.1.1 — Cho phép lưu ảnh nhỏ

## Lỗi trên máy người dùng
`Ảnh 40/66 lỗi lần 5/6: Ảnh quá nhỏ (950x1)` làm dừng hàng đợi tại Chap 030.

## Đã sửa
1. Trong `chapter_v5.py`, bỏ giới hạn mỗi cạnh ảnh tối thiểu 32 pixel. Ảnh có kích thước >0 và giải mã đầy đủ thì được lưu byte gốc, có SHA-256; các ảnh 950x1, 1x1 không tự bị loại.
2. Ghi cảnh báo hình bất thường vào `progress.json/warnings` và nhật ký, không dừng chap chỉ vì kích thước.
3. Trong `app.py`, nhận diện ảnh nhỏ ở trình duyệt nếu có URL; nếu có `data-original` hoặc `data-src` trỏ đến ảnh thật khác thì thử URL đó, nếu không thì giữ ảnh nhỏ hiện tại.
4. Giữ nguyên 1 chap mỗi lần, 5 lượt thử lại khi tải lỗi, ảnh gốc và chế độ PDF/HTML của v5.1.
5. Cập nhật phiên bản bên trong ứng dụng thành 5.1.1.

## Kiểm thử
- Test cho PNG 950x1 và 1x1, PDF dùng 950x1 không đổi kích thước, resume cache SHA-256.
- File HTML lỗi, ảnh bị cắt và ảnh rỗng vẫn bị từ chối.
- Tất cả bài hồi quy trong môi trường Linux: chạy `python -m unittest discover -s tests -p 'test_*.py' -v`.
- Chưa xác minh tải trọn Chap 030 trực tiếp trên trang DamCoNuong hoặc EXE Windows.

## Tạo bản trên GitHub
- Đưa `TruyenSaver_PRO_v5_1_Source.zip` mới lên thư mục gốc GitHub, thay bản cũ cùng tên.
- Giữ `.github/workflows/build-windows.yml` v5.1 như hiện tại. Chạy Actions -> Run workflow.
