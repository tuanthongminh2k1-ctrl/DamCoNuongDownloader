# TruyenSaver PRO v4.1 – DamCoNuong Optimized (Classic Tiếng Việt)

Đây là bản **nâng cấp trực tiếp từ TruyenSaver PRO v4 Classic** (không sử dụng HakuNeko/HaruNeko). Chạy Chromium kèm theo trong bản Portable; bản EXE chỉ có sau khi GitHub Actions build thành công.

## Nâng cấp riêng DamCoNuong.cool

1. **Quét chương đầy đủ hơn:** tích lũy kết quả khi danh sách tải dần, bấm nút *Xem thêm* khi thật sự xuất hiện; duyệt liên kết phân trang của **chính bộ truyện** (tối đa 40 trang danh sách). Nếu quá giới hạn, ghi cảnh báo thay vì báo đã lấy đủ.
2. **Không lẫn truyện khác:** xác thực domain và tiền tố URL bộ truyện, tách số chương khỏi chữ ngày tháng/lượt xem, xếp số chương chính xác kể cả 1.5.
3. **Tải có kiểm soát:** tối đa **một chương đồng thời** trên DamCoNuong; các nguồn khác giữ mức song song theo giao diện. Giãn nhịp khi lỗi mạng và thử lại những chương lỗi.
4. **Ảnh đầy đủ trước khi lưu:** ổn định danh sách ảnh, kiểm tra ảnh cuối, so sánh ảnh dự kiến với MHTML. Riêng DamCoNuong cho phép chụp lại MHTML tối đa ba lần khi bản chụp thiếu ảnh; KHÔNG đánh dấu hoàn thành khi thiếu ảnh.
5. **Khi mạng yếu:** kéo dài thời gian chờ ảnh ở DamCoNuong (95/130/165 giây qua ba lượt thử), giữ nguyên việc dừng toàn bộ ngay khi bạn yêu cầu.
6. **Lưu tên an toàn Windows:** loại ký tự không hợp lệ, khoảng trắng thừa, tên thiết bị `CON`/`PRN`/`NUL`... để tránh `EINVAL: mkdir`.
7. **Đọc PDF như website:** chiều rộng đều, không kéo méo ảnh, chia ảnh quá dài thành nhiều trang vừa đọc; vẫn hỗ trợ MHTML, PDF mỗi chương, PDF gộp.
8. **Giữ tiến độ v4:** MHTML v4.0 hợp lệ vẫn nhận diện khi tiếp tục, không bắt tải lại mọi chương.

**Giới hạn:** Công cụ kiểm tra công khai hiện không truy cập được trang DamCoNuong để kiểm thử trực tiếp. Do đó chức năng phân trang theo các liên kết thông thường và DOM hiện tại là phiên bản *thử nghiệm có kiểm thử giả lập*. Website thay đổi cấu trúc, nội dung ẩn, xác minh Cloudflare, hoặc đăng nhập vẫn có thể ngăn tải. Ứng dụng không tự vượt xác minh hoặc can thiệp cơ chế bảo vệ. Nếu trang yêu cầu đăng nhập, dùng nút **Đăng nhập (nếu cần)** với tài khoản của bạn.

## Cách tạo EXE trên GitHub (2 file)

1. Giải nén `TruyenSaver_PRO_v4_1_DamCoNuong_GitHub_2File.zip`.
2. Trong repository GitHub mới/trống, dùng **Add file → Upload files** đưa `TruyenSaver_PRO_v4_1_DamCoNuong_Source.zip` (GIỮ NGUYÊN ZIP, không giải nén) lên thư mục gốc rồi Commit.
3. Vào **Add file → Create new file**, đặt tên **`.github/workflows/build-windows.yml`**, dán toàn bộ nội dung file **`BUILD_GITHUB.yml`**, nhấn **Commit changes**.
4. Vào tab **Actions → TruyenSaver PRO v4.1 DamCoNuong Optimized - Windows → Run workflow**.
5. Nếu workflow xanh, mở **Artifacts → TruyenSaver-v4.1-DamCoNuong-Windows-Portable**. Tải artifact, giải nén **toàn bộ**, chạy `TruyenSaver_PRO_Classic.exe`. Không chuyển riêng EXE ra khỏi thư mục `_internal`.

Nếu xây dựng từ toàn bộ mã nguồn đã giải nén, `.github/workflows/build-windows.yml` cũng có sẵn để build theo cách thông thường.

## Cách tải truyện

1. Dán URL **trang bộ truyện** từ `https://damconuong.cool/truyen/...` (không dán địa chỉ trang chủ) vào ô URL. Có thể nhập nhiều bộ truyện mỗi dòng một URL.
2. Nhấn **QUÉT DANH SÁCH CHAP**. Kiểm tra số lượng và chọn những chương cần tải. Nếu nhật ký cảnh báo thiếu chương/phân trang, không giả định là đã quét hết.
3. Chọn thư mục lưu, chọn **PDF riêng / PDF gộp / MHTML**. Với DamCoNuong, chương trình tự giới hạn một tác vụ cùng lúc kể cả bạn chọn Song song = 3.
4. Nhấn **BẮT ĐẦU TẢI**. Khi đọc PDF trên PC, bật **Vừa chiều rộng** và **Cuộn liên tục** trong trình đọc PDF.
5. Nếu xuất hiện lỗi, chụp nội dung **Nhật ký chi tiết** để xác định xem bị giới hạn truy cập, thiếu ảnh hay thay đổi cấu trúc website.

## Trạng thái kiểm thử

- Đã chạy **68/68 unit test** tại môi trường Linux/Python: logic URL, phân trang, bộ đệm, MHTML, ảnh/PDF và hồi quy v4.
- **Chưa build và chạy EXE Windows trực tiếp trong phiên này**. GitHub Actions sẽ build và chạy bài tự kiểm tra trên Windows khi bạn tạo workflow.
- **Chưa xác nhận tải hoàn chỉnh từ DamCoNuong thật**, vì trang không truy cập được từ môi trường kiểm tra. Không thể hứa tất cả chap/ảnh khi trang giới hạn truy cập hay đổi mã.

Chỉ lưu nội dung mà bạn có quyền tải và sử dụng.
