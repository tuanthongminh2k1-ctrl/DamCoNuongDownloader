# Thay đổi TruyenSaver PRO v4.1 – DamCoNuong Optimized

- Bộ quét riêng cho damconuong.cool: xử lý danh sách chương nạp dần, nút xem thêm và tối đa 40 trang phân trang được liên kết trực tiếp.
- So khớp tên truyện và link chương chặt chẽ hơn để không lấy chương từ truyện khác.
- Chống lấy nhầm dữ liệu "1 năm trước", lượt xem thành số chương.
- Không chạy nhiều chương DamCoNuong cùng một lúc, nhưng không cản nguồn website khác.
- Thử tạo MHTML thêm hai lần khi chụp thiếu ảnh, thay vì kết luận lỗi ngay; không đánh dấu tệp thiếu ảnh đã hoàn thành.
- Tăng thời gian chờ DamCoNuong khi ảnh tải chậm.
- Giữ cách tạo PDF với chiều rộng đều đã có ở v4; sửa lọc tên thư mục gây lỗi Windows.
- Thêm 6 bài kiểm thử hồi quy DamCoNuong (68 bài tổng cộng).
